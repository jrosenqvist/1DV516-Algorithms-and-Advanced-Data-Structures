package assignment2AADS.assignment2;

public enum A2Direction {

    UP,
    RIGHT,
    DOWN, 
    LEFT
    
}
