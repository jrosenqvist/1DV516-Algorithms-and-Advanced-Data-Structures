package assignment2AADS.assignment2;

public interface A2Itinerary<T> {

    public T[] rotateRight();
    public int widthOfItinerary();
    public int heightOfItinerary();
    public int[] getIntersections();

    
}
