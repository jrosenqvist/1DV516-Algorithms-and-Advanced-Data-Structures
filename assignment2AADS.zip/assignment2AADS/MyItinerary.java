package assignment2AADS.assignment2;


public class MyItinerary implements A2Itinerary<A2Direction> {

//Add your code here
    
}
