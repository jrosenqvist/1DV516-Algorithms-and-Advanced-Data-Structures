package assignment3AADS.assignment3;

import java.util.List;

public class MySocialNetwork extends MyUndirectedGraph implements A3SocialNetwork {

    @Override
    public int numberOfPeopleAtFriendshipDistance(int vertexIndex, int distance) {
	// TODO Auto-generated method stub
	return 0;
    }

    @Override
    public int furthestDistanceInFriendshipRelationships(int vertexIndex) {
	// TODO Auto-generated method stub
	return 0;
    }

    @Override
    public List<Integer> possibleFriends(int vertexIndex) {
	// TODO Auto-generated method stub
	return null;
    }

}
