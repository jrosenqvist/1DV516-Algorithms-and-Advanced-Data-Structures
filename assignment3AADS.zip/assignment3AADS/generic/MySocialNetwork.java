package assignment3AADS.assignment3.generic;

import java.util.List;

public class MySocialNetwork<T> extends MyUndirectedGraph<T> implements A3SocialNetwork<T> {

    @Override
    public int numberOfPeopleAtFriendshipDistance(T vertex, int distance) {
	// TODO Auto-generated method stub
	return 0;
    }

    @Override
    public int furthestDistanceInFriendshipRelationships(T vertex) {
	// TODO Auto-generated method stub
	return 0;
    }

    @Override
    public List<T> possibleFriends(T vertex) {
	// TODO Auto-generated method stub
	return null;
    }

}
