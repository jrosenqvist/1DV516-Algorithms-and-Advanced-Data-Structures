package assignment1AADS.assignment1;



public interface A1Tree {
	public void insert(Integer value);
	public Integer mostSimilarValue(Integer value);
	public void printByLevels();
}
